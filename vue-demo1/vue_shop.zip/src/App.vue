<template>
  <div id="app">
    App根组件
  </div>
</template>
<script>
export default {
  name : 'app',
  data () {
    return {
  
    };
  },
  methods:{
  
  }
}
</script>
<style scoped lang="less">
  
</style>